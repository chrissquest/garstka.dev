

function jump(){
	console.log("jump");
}







